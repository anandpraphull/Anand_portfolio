var typed = new Typed("#element", {
    strings: ["FullStack Developer.", "Python||Flask||Pandas developer.","Skilled in HTML||CSS||JS.", "4 yrs Experienced in IT."],
    typeSpeed: 35,
    backSpeed: 35,
    loop: true
  });
  